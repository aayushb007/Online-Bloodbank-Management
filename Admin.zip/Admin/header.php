<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <div class="fl_left">
      <ul>
        <li><i class="fa fa-phone"></i> +00 (123) 456 7890</li>
        <li><i class="fa fa-envelope-o"></i> lifeonetouch@mail.in</li>
      </ul>
    </div>
    <div class="fl_right">
      <ul>
        <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="log1.php">Login</a></li>
        <li><a href="reg2.php">Register as donor</a></li>
      </ul>
    </div>
   </div>
</div>
<!-- ################################################################################################ -->
<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <h1><a href="index.php">Life@one touch</a></h1>
    <p>blood bank website</p>
    <!-- ################################################################################################ -->
  </header>
</div>
<!-- ################################################################################################ -->
<div class="wrapper row4">
  <nav id="mainav" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <ul class="clear">
      <li class="active"><a href="index.html">Home</a></li>
      <li><a class="drop" href="#">DONORS</a>
        <ul>
          <li><a href="howtodonate.php">HOW TO DONATE? </a></li>
          <li><a href="fd.php">FIND DONORS</a></li>
          <li><a href="">CAMPS</a></li>
          <li><a href="pages/sidebar-right.html">HOSPITALS</a></li>
          <li><a href="pages/basic-grid.html">DONOR DETAILS</a></li>
        </ul>
      </li>
      <li><a class="drop" href="#">BANK</a>
        <ul>
          <li><a href="#">ABOUT BLOOD BANK</a></li>
          <li><a class="drop" href="#">BLOOD</a>
            <ul>
              <li><a href="#">BLOODGROUPS</a></li>
              <li><a href="#">DETAILS</a></li>
            </ul>
          </li>
          <li><a href="connecthospital.php">CONNECT HOSPITALS
		  </a></li>
        </ul>
      </li>
	  <li><a href="about.php">ABOUT US</a></li>
	  <li><a href="contact.php">CONTACT US</a></li>
    </li>
    </ul>
    <!-- ################################################################################################ -->
  </nav>
</div>